
# Iris Flower Classification Using Machine Learning

**Student Name:** Hazarathbi Mulla

**Roll Number:** 20241CSE0680

**Institution:** Presidency University, Bengaluru

## Project Overview
This project classifies Iris flowers into three species
using a Random Forest Machine Learning algorithm.

## Dataset
Iris dataset containing 150 records and four features.

## Algorithm
Random Forest Classifier.

## Model Accuracy
90%

## Output
- Classification Report
- Confusion Matrix
- Feature Importance Graph
- Flower Species Prediction

## Tools
Python, Google Colab, Pandas, Matplotlib, Seaborn,
Scikit-learn.
